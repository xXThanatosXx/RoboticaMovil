############## Importar modulos #####################
from pyArduino import *

from tkinter import *
from PIL import Image, ImageTk

import cv2
import numpy as np
import sys
      
def toggle():
    btn.config(text=btnVar.get())

    
def onClossing():
    arduino.sendData([0,0])
    arduino.close()
    root.quit()         #Salir del bucle de eventos.
    cap.release()       #Cerrar camara
    print("Ip Cam Disconected")
    root.destroy()      #Destruye la ventana creada
    
def hsvValue(int):
    hMin.set(slider1.get())
    hMax.set(slider2.get())
    sMin.set(slider3.get())
    sMax.set(slider4.get())
    vMin.set(slider5.get())
    vMax.set(slider6.get())
    
def objectDetection(rawImage):
    
    kernel = np.ones((10,10),np.uint8) # Filtro
    isObject = False     # Verdadero si encuentra un objeto
    cx,cy = 0,0          #centroide (x), centroide (y)
    
    minArea = 50  # Area minima para considerar que es un objeto

    ################# Procesamiento de la Imagen ################
    
    hsv = cv2.cvtColor(rawImage, cv2.COLOR_BGR2HSV) #Convertirlo a espacio de color HSV
    #Se crea un array con las posiciones minimas y maximas capturadas de los sliders
    lower=np.array([hMin.get(),sMin.get(),vMin.get()])
    upper=np.array([hMax.get(),sMax.get(),vMax.get()])
     
    #Deteccion de colores 
    mask = cv2.inRange(hsv, lower, upper)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
    contours,_ = cv2.findContours(mask.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    for cnt in contours:
        #Calcular el centro a partir de los momentos
        momentos = cv2.moments(cnt)
        area = momentos['m00']
        if (area>minArea):
            cv2.drawContours(rawImage,[i],0,(255,0,0),-1)
            cx = int(momentos['m10']/momentos['m00'])
            cy = int(momentos['m01']/momentos['m00'])
            isObject = True
            
    return isObject,mask,rawImage,cx,cy
    
    
def callback():

        ################## Adquisición de la Imagen ############
        
        cap.open(url) # Antes de capturar el frame abrimos la url
        ret, frame = cap.read() # Leer Frame
        
        if ret:
            
            isObject,mask,frame,cx,cy = objectDetection(frame)
            
            minDist = 20
            
            cv2.circle(frame,(cx,cy),10, (0,0,255), -1)
            cv2.circle(frame,(cxd,cyd),minDist, (0,255,0),3)

                                   
            if isObject:
                

                ################## Conversion coordenadas ############
 
                hx = cx-frame.shape[1]/2
                hy = frame.shape[0]/2-cy
                
                # Distancia minima de error (Distancia Euclidiana)

                distance = np.sqrt((hxd-hx)**2+(hyd-hy)**2)
                
                if distance>minDist:
                    
                    ################## Control cámara en mano ############
                    
                    a = 0.07 # punto de interes en metros (Donde se coloca el objeto)
                    phi.set(arduino.rawData[0]) 

                    # Errores
                    
                    hxe  =  hxd-hx
                    hye  =  hyd-hy

                    
                    he = np.array([[hxe],[hye]])

                    K = np.diag([0.001,0.001])

                    J = np.array([[-np.sin(phi.get()),-a*np.cos(phi.get())],
                                  [ np.cos(phi.get()),-a*np.sin(phi.get())]])
                    # Ley de control
                    qp = np.linalg.inv(J)@(K@he)
                    
                    uRef.set(round(qp[0][0],3))
                    wRef.set(round(qp[1][0],3))

                    
                else:
                    uRef.set(0)
                    wRef.set(0)
            else:
                uRef.set(0)
                wRef.set(0)

                

            varU.set("Linear velocity : "+str(uRef.get()))
            varW.set("Angular velocity : "+str(wRef.get()))
            varPhi.set("Orientation: "+str(phi.get()))
            
            # Boton de inicio
            if btnVar.get() == 'Start':
                arduino.sendData([uRef.get(),wRef.get()])
            else:
                arduino.sendData([0,0])


            # Mostrar imagen en el HMI 
            img = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)    
            img = Image.fromarray(img)
            img.thumbnail((400,400))
            tkimage = ImageTk.PhotoImage(img)
            label.configure(image = tkimage)
            label.image = tkimage
            
            img1 = Image.fromarray(mask)
            img1.thumbnail((400,400))
            tkimage1 = ImageTk.PhotoImage(img1) 
            label1.configure(image = tkimage1)
            label1.image = tkimage1
            
            root.after(10,callback)
            
        else:
            onClossing()
            
########################### Ip Cam ###########################
url='http://192.168.137.75:8080/shot.jpg'
cap = cv2.VideoCapture(url)

if cap.isOpened():
    print("Ip Cam initializatized")
else:
    sys.exit("Ip Cam disconnected")

cap.open(url)    
ret, frame = cap.read()

####################### Desired position in pixels ##############

cxd = 340
cyd = 240

hxd = cxd - frame.shape[1]/2
hyd = frame.shape[0]/2 - cyd


########################### Serial communication ###########

port = 'COM17' 
arduino = serialArduino(port)
arduino.readSerialStart()

############################## HMI design #################


root = Tk()
root.protocol("WM_DELETE_WINDOW",onClossing)
root.title("Vision Artificial") # titulo de la ventana

label=Label(root) 
label.grid(padx=20,pady=20)

label1=Label(root)
label1.grid(row = 0,column=1,padx=20,pady=20)

uRef = DoubleVar(root,0)
varU = StringVar(root,"Linear velocity : 0.00")        
labelU = Label(root, textvariable = varU)
labelU.grid(row = 1,padx=20,pady=10)

wRef = DoubleVar(root,0)
varW = StringVar(root,"Angular velocity : 0.00")
labelW = Label(root, textvariable = varW)
labelW.grid(row= 1,column = 1, padx=20,pady=10)

phi = DoubleVar(root,0)
varPhi = StringVar(root,"Orientation : 0.00")
labelPhi = Label(root, textvariable = varPhi)
labelPhi.grid(row= 2, padx=20,pady=10)


hMin = IntVar()
hMax = IntVar()
sMin = IntVar()
sMax = IntVar()
vMin = IntVar()
vMax = IntVar()

slider1 = Scale(root,label = 'Hue Min', from_=0, to=255, orient=HORIZONTAL,command=hsvValue,length=400)   #Creamos un dial para recoger datos numericos
slider1.grid(row = 3)
slider2 = Scale(root,label = 'Hue Max', from_=0, to=255, orient=HORIZONTAL,command=hsvValue,length=400)   #Creamos un dial para recoger datos numericos
slider2.grid(row = 3,column=1)
slider3 = Scale(root,label = 'Saturation Min', from_=0, to=255, orient=HORIZONTAL,command=hsvValue,length=400)   #Creamos un dial para recoger datos numericos
slider3.grid(row = 4)
slider4 = Scale(root,label = 'Saturation Max', from_=0, to=255, orient=HORIZONTAL,command=hsvValue,length=400)   #Creamos un dial para recoger datos numericos
slider4.grid(row = 4,column=1)
slider5 = Scale(root,label = 'Value Min', from_=0, to=255, orient=HORIZONTAL,command=hsvValue,length=400)   #Creamos un dial para recoger datos numericos
slider5.grid(row = 5)
slider6 = Scale(root,label = 'Value Max', from_=0, to=255, orient=HORIZONTAL,command=hsvValue,length=400)   #Creamos un dial para recoger datos numericos
slider6.grid(row = 5,column=1)

slider1.set(60)
slider3.set(125)
slider5.set(138)

slider2.set(164)
slider4.set(255)
slider6.set(255)

btnVar = StringVar(root, 'Pause')
btn = Checkbutton(root, text=btnVar.get(), width=12, variable=btnVar,
                  offvalue='Pause', onvalue='Start', indicator=False,
                  command=toggle)
btn.grid(row = 6, padx=20,pady=20)

root.after(10,callback) #Es un método definido para todos los widgets tkinter.
root.mainloop()

